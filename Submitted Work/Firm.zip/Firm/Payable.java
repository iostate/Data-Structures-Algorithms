/**
 *
 Programmer: Quan Truong
 Date: 6/20/17
 Class: CSC205
 Professor: Mrs. Heil
 Assignment: Payable

 Description: An interface used to pay the employees.

 */
package Firm;

public interface Payable {
    double pay();
}


