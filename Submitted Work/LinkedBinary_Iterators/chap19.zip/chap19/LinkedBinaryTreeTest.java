import jsjf.LinkedBinaryTree;

import java.util.Iterator;

/**
 * Demonstrates the functionality of the toString method as well as the
 * getRootElement methods.
 */
public class LinkedBinaryTreeTest {

    public static void main(String[] args) {
        LinkedBinaryTree<Integer> orangeTree = new LinkedBinaryTree(2,
                new LinkedBinaryTree(3), new LinkedBinaryTree(4));

        System.out.println("In order Iterator: ");
        createAndPrintInOrderIterator(orangeTree);
        System.out.println("Post order Iterator: ");
        createAndPrintPostOrderIterator(orangeTree);
        System.out.println("Pre order Iterator: ");
        createAndPrintPreOrderIterator(orangeTree);
    }

    public static void createAndPrintInOrderIterator(LinkedBinaryTree<Integer> aTree) {
        Iterator inOrder = aTree.iteratorInOrder();

        while (inOrder.hasNext()) {
            System.out.println(inOrder.next());
        }
    }

    public static void createAndPrintPostOrderIterator(LinkedBinaryTree<Integer> aTree) {
        Iterator postOrder = aTree.iteratorPostOrder();

        while (postOrder.hasNext()) {
            System.out.println(postOrder.next());
        }
    }

    public static void createAndPrintPreOrderIterator(LinkedBinaryTree<Integer> aTree) {
        Iterator preOrder = aTree.iteratorPreOrder();

        while (preOrder.hasNext()) {
            System.out.println(preOrder.next());
        }
    }
}
