//Never finished this..
// Check the FamilyTree png in this source file to finish later

//import jsjf.BinaryTreeNode;
//
///**
// * Created by qmtruong92 on 7/18/17.
// */
//public class FamilyTree {
//
//
//
//    public FamilyTree(ExpressionTreeOp element,
//                          ExpressionTree leftSubtree, ExpressionTree rightSubtree)
//    {
//        root = new BinaryTreeNode<FamilyTreeOp>(element, leftSubtree, rightSubtree);
//    }
//
//
//
//}
