package Speaker;

/**
 * Created by qmtruong92 on 6/20/17.
 */
public interface SpeakerInterface {

    public void speak();
    public void announce(String str);
}
