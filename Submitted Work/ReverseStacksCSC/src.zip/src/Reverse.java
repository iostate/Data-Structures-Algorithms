
import jsjf.ArrayStack;

/**
 * Created by qmtruong92 on 7/3/17.
 */
public class Reverse<T> extends ArrayStack<T> {

    private ArrayStack<T> myStack;


    public Reverse(int size) {

        myStack = new ArrayStack<T>(size);

    }

    public static void main(String[] args) {

    }




}
