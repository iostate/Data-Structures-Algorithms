
/**
 * Created by qmtruong92 on 6/18/17.
 */
public class Receptionist extends HospitalEmployees {

    public Receptionist(String name, int age, double salary,
                        double hoursPerWeek, int yearsAsEmployee) {
        super(name, age, salary, hoursPerWeek, yearsAsEmployee);

    }

}
