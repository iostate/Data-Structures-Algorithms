import jsjf.LinkedBinaryTree;

import java.util.Iterator;

/**
 * Demonstrates the functionality of the find and contains method of the
 * LinkedBinarySearchTree.
 */
public class LinkedBinaryTreeTest {

    public static void main(String[] args) {
        LinkedBinaryTree<Integer> orangeTree = new LinkedBinaryTree(2,
                new LinkedBinaryTree(3), new LinkedBinaryTree(4));

        //Demonstrating the find method
        System.out.println(orangeTree.find(2));
        //Demonstrating the contains method
        System.out.println(orangeTree.contains(2));


    }

    public static void createAndPrintInOrderIterator(LinkedBinaryTree<Integer> aTree) {
        Iterator inOrder = aTree.iteratorInOrder();

        while (inOrder.hasNext()) {
            System.out.println(inOrder.next());
        }
    }

    public static void createAndPrintPostOrderIterator(LinkedBinaryTree<Integer> aTree) {
        Iterator postOrder = aTree.iteratorPostOrder();

        while (postOrder.hasNext()) {
            System.out.println(postOrder.next());
        }
    }

    public static void createAndPrintPreOrderIterator(LinkedBinaryTree<Integer> aTree) {
        Iterator preOrder = aTree.iteratorPreOrder();

        while (preOrder.hasNext()) {
            System.out.println(preOrder.next());
        }
    }

    public static void createAndPrintLevelOrderIterator(LinkedBinaryTree<Integer> aTree) {
        Iterator inOrder = aTree.iteratorLevelOrder();

        while (inOrder.hasNext()) {
            System.out.println(inOrder.next());
        }
    }
}
