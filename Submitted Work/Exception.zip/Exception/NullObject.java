package Exception;

/**
 * Created by qmtruong92 on 6/22/17.
 */
public class NullObject {

    public String name;

    public NullObject(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
