import jsjf.exceptions.InvalidInputException;

/**
 * Created by qmtruong92 on 7/11/17.
 */
public class TEST_StringFormat {

   public static void main(String[] args) {







      Simulator simulator = new Simulator();

      String num =  "1000";

//      System.out.println(simulator.falseSimulationTimeCheck(num));

//      String probability;
//      int probabilityInt = 0;
//      Simulator simulator = new Simulator();
//
//      System.out.println("Enter probability (1-100): ");
//      probability = simulator.KB.next();
//      while (simulator.falseProbabilityCheck(probability)) {
//         try {
//            if (simulator.falseProbabilityCheck(probability)) {
//               throw new InvalidInputException(probability);
//            }
//
//
//         } catch (InvalidInputException e) {
//            System.out.println("Please enter an integer (1-100).");
//
//         }
//
//         System.out.println("Enter probability: ");
//         probability = simulator.KB.next();
//      }
//      probabilityInt = Integer.parseInt(probability);
//
//      System.out.println(Integer.parseInt("100"));
//
//      System.out.println(probabilityInt);


   }

}
