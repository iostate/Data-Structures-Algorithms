/**
 * Created by qmtruong92 on 6/4/17.
 */
public class StringReviewMain {

    public static void main(String[] args) {

        StringReview.doStringReview();

    }
}
