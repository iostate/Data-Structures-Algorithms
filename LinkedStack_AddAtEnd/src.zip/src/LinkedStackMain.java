import jsjf.*;
/**
 * Create a Linked stack.
 */
public class LinkedStackMain {

    public static void main(String[] args) {

        LinkedStack<String> theStack = new LinkedStack();

       System.out.println("Pushing 1 onto stack...");
        theStack.push("1");
       System.out.println("Pushing 2 onto stack...");
        theStack.push("2");
       System.out.println("Pushing 3 to end of stack...");
        theStack.addAtEnd("3");
       System.out.println("Pushing 4 to end of stack...");
        theStack.addAtEnd("4");

       System.out.print("First Element: ");
       System.out.println(theStack.peek().toString() +"\n");

       System.out.print("Number of Elements: " + theStack.size() + "\n");

       System.out.println("Is the stack empty? " + theStack.isEmpty() +"\n");


       System.out.println("Printing stack...");
       System.out.println(theStack.toString());






    }
}
